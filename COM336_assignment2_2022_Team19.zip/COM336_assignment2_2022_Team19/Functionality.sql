--Adding a new product
INSERT INTO `product` (`ProductID`, `Model`, `Year_Produced`, `Primary_Colour`, `Secondary_Colour`, `Engine_Size`, `Fuel`, `Mileage`, `Vehicle_Weight`, `Price`, `PackageID`, `OptionsID`) 
VALUES (default, 'A7', 2015, 'Grey', 'Black', 3, 'Diesel', 26730, 1475, 35600, 3, 1),

--Changing price of a product
UPDATE product
SET Price = Price + 1000
WHERE ProductID = 2

--Shopping cart
CREATE VIEW ShoppingCart AS
SELECT ProductID, Model, Year_Produced, Fuel, Mileage, Primary_Colour, Secondary_Colour, Price
FROM product
WHERE ProductID = 3

--Change Customer details
UPDATE customer
SET TelephoneNO = '07173826455'
WHERE CustomerNo = 4

UPDATE customer
SET Email = 'KennyRobinson@gmail.com'
WHERE CustomerNo = 2

--Displaying a review
SELECT Review, CustomerNo, Review_date From Reviews 
WHERE CustomerNo = 1

--Adding a review
INSERT INTO Reviews (CustomerNo, ProductID, Rating, Review, Review_date)
Values (3, 3, 4, 'Testing review functionality', 2022-04-14)