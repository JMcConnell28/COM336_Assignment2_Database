

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `audidealership`
--

CREATE USER 'admin'@'%' IDENTIFIED BY 'Password123';
GRANT ALL PRIVILEGES ON *.* TO 'admin'@'%' WITH GRANT OPTION;

CREATE USER 'TestUser'@'%' IDENTIFIED BY 'testpassword';
GRANT SELECT ON dealership.* TO 'TestUser'@'%'

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `calcOrderTotal`$$
CREATE DEFINER=`admin`@`%` PROCEDURE `calcOrderTotal` ()  BEGIN

	DECLARE counter INT;
    SET counter = 1;
    
    loop_label: LOOP
    	IF counter > (SELECT COUNT(OrderNo) FROM orders) THEN
        	LEAVE loop_label;
        END IF;
        
        
        IF counter <= (SELECT COUNT(OrderNo) FROM orders) THEN
        	UPDATE orders 
            SET Total = (Subtotal) +
            (SELECT options.Price FROM options WHERE optionsID = (SELECT product.optionsID FROM product WHERE productID = (orders.productID))) +
            (SELECT packages.Price FROM packages where packageID = (SELECT product.packageID FROM product WHERE productID = (orders.productID))) + (SELECT delivery.Delivery_Charge FROM delivery where OrderNo = (orders.OrderNo))
            WHERE OrderNo = counter;
        END IF;
        SET counter = counter + 1;
     END LOOP;

END$$

DROP PROCEDURE IF EXISTS `calcRemain`$$
CREATE DEFINER=`admin`@`%` PROCEDURE `calcRemain` ()  BEGIN

	DECLARE counter INT;
    SET counter = 1;
    
    loop_label: LOOP
    	IF counter > (SELECT COUNT(PaymentID) FROM payment) THEN
        	LEAVE loop_label;
        END IF;
        
        
        IF counter <= (SELECT COUNT(PaymentID) FROM payment) THEN
        	UPDATE payment 
            SET Remaining = (SELECT orders.Total FROM orders WHERE OrderNo = payment.OrderNo) - Amount_Paid
            WHERE PaymentID = counter;
        END IF;
        SET counter = counter + 1;
     END LOOP;

END$$

DROP PROCEDURE IF EXISTS `calcSubtotal`$$
CREATE DEFINER=`admin`@`%` PROCEDURE `calcSubtotal` ()  BEGIN

	DECLARE counter INT;
    SET counter = 1;
    
    loop_label: LOOP
    	IF counter > (SELECT COUNT(OrderNo) FROM orders) THEN
        	LEAVE loop_label;
        END IF;
        
        
        IF counter <= (SELECT COUNT(OrderNo) FROM orders) THEN
        	UPDATE orders 
            SET Subtotal = (SELECT product.Price FROM product WHERE productID = orders.ProductID) * Quantity
            WHERE OrderNo = counter;
        END IF;
        SET counter = counter + 1;
     END LOOP;

END$$

DROP PROCEDURE IF EXISTS `InvoiceData`$$
CREATE DEFINER=`admin`@`%` PROCEDURE `InvoiceData` ()  BEGIN
		DECLARE counter INT;
    	SET counter = 1;
    
    loop_label: LOOP
    	IF counter > (SELECT COUNT(InvoiceID) FROM invoice) THEN
        	LEAVE loop_label;
        END IF;
        
        
        IF counter <= (SELECT COUNT(InvoiceID) FROM invoice) THEN
        	UPDATE invoice 
            SET VehicleCost = (SELECT product.Price FROM product WHERE productID = invoice.ProductID), 
            PackageCost = (SELECT packages.Price FROM packages where packageID = (SELECT product.packageID FROM product WHERE productID = invoice.productID)),
            OptionsCost = (SELECT options.Price FROM options WHERE optionsID = (SELECT product.optionsID FROM product WHERE productID = invoice.productID)),
            DeliveryCost = (SELECT delivery.Delivery_Charge FROM delivery where OrderNo = invoice.OrderNo),
            Total = VehicleCost + PackageCost + OptionsCost
            WHERE InvoiceID = counter;
        END IF;
        SET counter = counter + 1;
     END LOOP;

END$$

DROP PROCEDURE IF EXISTS `passwordHash`$$
CREATE DEFINER=`admin`@`%` PROCEDURE `passwordHash` ()  BEGIN

	DECLARE counter INT;
    SET counter = 1;
    
    loop_label: LOOP
    	IF counter > (SELECT COUNT(CustomerNo) FROM login) THEN
        	LEAVE loop_label;
        END IF;
        
        
        IF counter <= (SELECT COUNT(CustomerNo) FROM login) THEN
        	UPDATE login 
            SET Passwords = md5(Passwords)
            WHERE CustomerNo = counter;
        END IF;
        SET counter = counter + 1;
     END LOOP;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `CustomerNo` int(11) NOT NULL AUTO_INCREMENT,
  `Forename` varchar(15) NOT NULL,
  `Surname` varchar(15) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `TelephoneNO` varchar(11) NOT NULL,
  `PostCode` varchar(7) NOT NULL,
  PRIMARY KEY (`CustomerNo`),
  KEY `PostCode` (`PostCode`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CustomerNo`, `Forename`, `Surname`, `Email`, `TelephoneNO`, `PostCode`) VALUES
(1, 'John', 'Doe', 'JDoe@gmail.com', '01234567891', 'BT521TE'),
(2, 'Kenneth', 'Robinson', 'kennyr@hotmail.co.uk', '07845158450', 'BT197TR'),
(3, 'Charles', 'Clarke', 'charlieclarke315@yahoo.com', '02836419875', 'BT148FS'),
(4, 'Angela', 'Campbell', 'angelacampbell@gmail.com', '07816794305', 'BT476YY'),
(5, 'Simon', 'Reed', 'reeds@gmail.com', '07932105937', 'BT196AR');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
CREATE TABLE IF NOT EXISTS `delivery` (
  `OrderNo` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Delivery_Method` enum('Express','Standard','Collection') NOT NULL,
  `Delivery_Charge` enum('100','35','0') NOT NULL,
  PRIMARY KEY (`OrderNo`,`ProductID`),
  KEY `ProductID` (`ProductID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`OrderNo`, `ProductID`, `Delivery_Method`, `Delivery_Charge`) VALUES
(1, 1, 'Express', '100'),
(2, 4, 'Collection', '0'),
(3, 3, 'Standard', '35'),
(4, 2, 'Express', '100'),
(5, 5, 'Collection', '0'),
(6, 1, 'Collection', '0');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
CREATE TABLE IF NOT EXISTS `invoice` (
  `InvoiceID` int(11) NOT NULL AUTO_INCREMENT,
  `VehicleCost` float DEFAULT NULL,
  `PackageCost` float NOT NULL,
  `OptionsCost` float NOT NULL,
  `DeliveryCost` float NOT NULL,
  `Total` float NOT NULL,
  `CustomerNo` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `OrderNo` int(11) NOT NULL,
  `PaymentID` int(11) NOT NULL,
  PRIMARY KEY (`InvoiceID`),
  KEY `CustomerNo` (`CustomerNo`),
  KEY `ProductID` (`ProductID`),
  KEY `OrderNo` (`OrderNo`),
  KEY `PaymentID` (`PaymentID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`InvoiceID`, `VehicleCost`, `PackageCost`, `OptionsCost`, `DeliveryCost`, `Total`, `CustomerNo`, `ProductID`, `OrderNo`, `PaymentID`) VALUES
(1, 15299, 10650, 1500, 100, 27449, 1, 1, 1, 1),
(2, 14900, 21500, 1100, 0, 37500, 2, 4, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `CustomerNo` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(15) NOT NULL,
  `Passwords` varchar(100) NOT NULL,
  PRIMARY KEY (`CustomerNo`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`CustomerNo`, `Username`, `Passwords`) VALUES
(1, 'John24', '*AA53007F667C212EBC60E49AAD97601E2E973840'),
(2, 'Robin94', '*68FEFFE887FD9468B74AEA745EB41B04C00847A9'),
(3, 'Charles5', '*CBC923AFB6A37D409B8811B463600145F2BB0DCF'),
(4, 'Angel4', '*E3E624F0AB44EE999C60206C2C29348863EC1F82'),
(5, 'Simon67', '*CD51C504060C1FD1F1307B43F6766D303B157458');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `OptionsID` int(11) NOT NULL AUTO_INCREMENT,
  `Option_Name` varchar(20) NOT NULL,
  `Option_Description` varchar(255) NOT NULL,
  `Price` float NOT NULL,
  PRIMARY KEY (`OptionsID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`OptionsID`, `Option_Name`, `Option_Description`, `Price`) VALUES
(1, 'N/A', 'N/A', 0),
(2, 'Bose Sound System', 'Top specification sound system to provide ultra crisp music with full surround sound capabilities.', 1500),
(3, 'Heated Seating', 'Fully controllable heated seating for the driver and all passengers', 1100),
(4, 'Cruise Control', 'Advanced cruise control at the push of a button, have full control over your speed and keep in lane with automatic lane assist.', 1400);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `OrderNo` int(11) NOT NULL AUTO_INCREMENT,
  `Order_Date` date NOT NULL,
  `Shipping_Address` varchar(255) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Subtotal` float NOT NULL,
  `Total` float NOT NULL,
  `CustomerNo` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `OrderStatus` enum('Pending','Complete') NOT NULL,
  PRIMARY KEY (`OrderNo`),
  KEY `CustomerNo` (`CustomerNo`),
  KEY `ProductID` (`ProductID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderNo`, `Order_Date`, `Shipping_Address`, `Quantity`, `Subtotal`, `Total`, `CustomerNo`, `ProductID`, `OrderStatus`) VALUES
(1, '2021-06-18', '5 Glenbeg Court, Coleraine', 1, 15299, 27549, 1, 1, 'Complete'),
(2, '2022-01-26', '19 Bexley Mdw, Bangor', 1, 14900, 37500, 2, 4, 'Complete'),
(3, '2021-08-03', '29 Squires View, Belfast', 1, 28600, 28635, 3, 3, 'Pending'),
(4, '2021-12-03', '44 Abbeydale, Londonderry', 1, 8540, 19290, 4, 2, 'Pending'),
(5, '2022-01-29', '29 Bayview Rd, Bangor', 1, 29800, 29800, 5, 5, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
CREATE TABLE IF NOT EXISTS `packages` (
  `PackageID` int(11) NOT NULL AUTO_INCREMENT,
  `Package_Name` varchar(20) DEFAULT NULL,
  `Package_Description` varchar(255) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  PRIMARY KEY (`PackageID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`PackageID`, `Package_Name`, `Package_Description`, `Price`) VALUES
(1, 'Sport', 'The sport package comes with Audis famous Quattro four-wheel drive, Upgraded Sport Suspension that stiffens up the ride for a super tight drive. Bold sport wheels elevate Audi Sport even more, giving high performance cars a premium touch.', 10650),
(2, 'Racing Sport', 'Audis pinnacle of racing performance. Leather upholstery embossed with bold RS details. Exclusive sport engine tuned for racing. Latest advancements in driving technology.', 21500),
(3, 'N/A', 'N/A', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `PaymentID` int(11) NOT NULL AUTO_INCREMENT,
  `Payment_Method` enum('Cash','Debit card','Credit card') NOT NULL,
  `Amount_Paid` float NOT NULL,
  `Remaining` float NOT NULL,
  `Date_Paid` date NOT NULL,
  `CustomerNo` int(11) NOT NULL,
  `OrderNo` int(11) NOT NULL,
  PRIMARY KEY (`PaymentID`),
  KEY `CustomerNo` (`CustomerNo`),
  KEY `OrderNo` (`OrderNo`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `Payment_Method`, `Amount_Paid`, `Remaining`, `Date_Paid`, `CustomerNo`, `OrderNo`) VALUES
(1, 'Debit card', 15299, 12250, '2021-06-18', 1, 1),
(2, 'Debit card', 10000, 27500, '2022-01-26', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `postcode`
--

DROP TABLE IF EXISTS `postcode`;
CREATE TABLE IF NOT EXISTS `postcode` (
  `PostCode` varchar(7) NOT NULL,
  `Customer_Address` varchar(255) NOT NULL,
  PRIMARY KEY (`PostCode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postcode`
--

INSERT INTO `postcode` (`PostCode`, `Customer_Address`) VALUES
('BT521TE', '5 Glenbeg Court, Coleraine'),
('BT197TR', '19 Bexley Mdw, Bangor'),
('BT148FS', '29 Squires Vw, Belfast'),
('BT476YY', '44 Abbeydale, Waterside, Londonderry'),
('BT196AR', '29 Bayview Rd, Bangor');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `Model` varchar(15) NOT NULL,
  `Year_Produced` int(11) NOT NULL,
  `Primary_Colour` varchar(10) NOT NULL,
  `Secondary_Colour` varchar(10) DEFAULT NULL,
  `Engine_Size` float NOT NULL,
  `Fuel` varchar(8) NOT NULL,
  `Mileage` int(6) NOT NULL,
  `Vehicle_Weight` float NOT NULL,
  `Price` float NOT NULL,
  `PackageID` int(11) NOT NULL,
  `OptionsID` int(11) NOT NULL,
  PRIMARY KEY (`ProductID`),
  KEY `PackageID` (`PackageID`),
  KEY `OptionsID` (`OptionsID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `Model`, `Year_Produced`, `Primary_Colour`, `Secondary_Colour`, `Engine_Size`, `Fuel`, `Mileage`, `Vehicle_Weight`, `Price`, `PackageID`, `OptionsID`) VALUES
(1, 'A4', 2016, 'Black', 'Grey', 2, 'Diesel', 32045, 1415, 15299, 1, 2),
(2, 'A4', 2012, 'Silver', NULL, 2, 'Diesel', 89253, 1475, 8540, 1, 1),
(3, 'A4', 2021, 'Navy', 'Black', 2, 'Diesel', 2073, 1535, 28600, 3, 1),
(4, 'A5', 2013, 'White', 'Black', 2, 'Diesel', 62473, 1590, 14900, 2, 3),
(5, 'A5', 2021, 'Red', 'Grey', 2, 'Petrol', 3128, 1573, 29800, 3, 1),
(6, 'A5', 2021, 'Navy', 'Black', 2, 'Diesel', 2073, 1535, 28600, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `CustomerNo` int(11) NOT NULL,
  `ProductID` varchar(20) NOT NULL,
  `Rating` enum('1','2','3','4','5') NOT NULL,
  `Review` varchar(255) NOT NULL,
  `Review_date` date NOT NULL,
  PRIMARY KEY (`CustomerNo`,`ProductID`),
  KEY `ProductID` (`ProductID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`CustomerNo`, `ProductID`, `Rating`, `Review`, `Review_date`) VALUES
(1, '1', '4', 'Performance is excellent with 0/60 in 5.3 seconds while getting respectable MPGs. The interior and dash layout are the best and its class with the GPS screen thats viewable right in front of the driver.', '2021-06-18'),
(2, '4', '5', 'One of just a few 3 second cars 0 to 60. The understated but stylish sheet metal lulls the exotics then blows them away. Fastest car Ive ever owned and also the best looking.', '2022-04-06');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `Model` varchar(15) NOT NULL,
  `Year_Produced` int(11) NOT NULL,
  `Stock_level` int(11) NOT NULL,
  PRIMARY KEY (`Model`,`Year_Produced`),
  KEY `Year_Produced` (`Year_Produced`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`Model`, `Year_Produced`, `Stock_level`) VALUES
('A4', 2016, 4),
('A4', 2012, 2),
('A4', 2021, 1),
('A5', 2013, 3),
('A5', 2021, 2);



COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
